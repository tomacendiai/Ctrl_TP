from setuptools import setup, find_packages

setup(
    name='Ctrl_TP',
    version='1.0',
    packages=find_packages(exclude=['tests*']),
    author="Thomas SANDIER",
    author_email="thomas.sandier@cpe.fr",
    description="évaluation TP de AdmCO",
)