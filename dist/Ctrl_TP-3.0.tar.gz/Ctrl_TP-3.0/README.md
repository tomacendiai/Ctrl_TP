# Ctrl_TP

afin de télécharger une version zippé de ce projet il vous suffit de le télécharger depuis le dossier "dist" présent dans ce projet github

Pour lancer une partie il vous suffit de taper la commande "python Main/main.py" lorsque vous vous trouvez dans le dossier Ctrl_TP
